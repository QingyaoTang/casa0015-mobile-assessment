
<img class='logo' src='./chao.png' alt='chao' />

> QQ音乐API koa2实现版本

* 当前代码仅共学习，不可做商业用途
* 希望大家一起学习，有大佬愿意带我就更好了

[GitHub](https://github.com/rain120/qq-music-api)
[Get Started](#qqmusicapi)